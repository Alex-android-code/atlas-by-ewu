import os
from dotenv import load_dotenv
load_dotenv()
TELEGRAM_TOKEN=os.getenv("TELEGRAM_TOKEN","").strip()
GEMINI_API_KEY=os.getenv("GEMINI_API_KEY","").strip()
GOOGLE_SCRIPT_URL=os.getenv("GOOGLE_SCRIPT_URL","").strip()
OPERATIONS_CHAT_ID=os.getenv("OPERATIONS_CHAT_ID","").strip()
LEADS_CHANNEL_ID=os.getenv("LEADS_CHANNEL_ID","").strip()
ADMIN_CHAT_ID=os.getenv("ADMIN_CHAT_ID","").strip()
DEFAULT_LANG=os.getenv("DEFAULT_LANG","pl")
BANNER_FILE=os.getenv("BANNER_FILE","assets/ewu_banner.png")
MENU_FILE=os.getenv("MENU_FILE","assets/ewu_menu.png")
LOGO_FILE=os.getenv("LOGO_FILE","assets/ewu_logo.png")
EWU_DATA_DIR=os.getenv("EWU_DATA_DIR","EWU_Data")
LOCAL_BACKUP_FILE=os.getenv("LOCAL_BACKUP_FILE","EWU_Data/Backups/local_backup_leads.jsonl")
PDF_DIR=os.getenv("PDF_DIR","EWU_Data/PDF")
SUPPORTED_LANGS=["pl","ua","ru","en","de","es","pt"]
