import os,json,requests,time
from datetime import datetime,timezone
from config import GOOGLE_SCRIPT_URL,LOCAL_BACKUP_FILE,EWU_DATA_DIR
def now_iso(): return datetime.now(timezone.utc).isoformat()
def ensure_dirs():
    for f in ["Candidates","Employers","Photos","PDF","Backups","Logs"]: os.makedirs(os.path.join(EWU_DATA_DIR,f),exist_ok=True)
def log_error(src,e):
    ensure_dirs(); open(os.path.join(EWU_DATA_DIR,"Logs","errors.log"),"a",encoding="utf-8").write(json.dumps({"time":now_iso(),"source":src,"error":str(e)},ensure_ascii=False)+"\n")
def backup(table,data,reason=""):
    ensure_dirs(); os.makedirs(os.path.dirname(LOCAL_BACKUP_FILE),exist_ok=True)
    open(LOCAL_BACKUP_FILE,"a",encoding="utf-8").write(json.dumps({"time":now_iso(),"table":table,"data":data,"reason":reason},ensure_ascii=False)+"\n")
def send_crm(action,table,data):
    backup(table,data,"local backup")
    if not GOOGLE_SCRIPT_URL: return False,"NO_GOOGLE_SCRIPT_URL"
    for _ in range(3):
        try:
            r=requests.post(GOOGLE_SCRIPT_URL,json={"action":action,"table":table,"data":data},timeout=25)
            return r.status_code==200 and '"ok":true' in r.text.replace(" ","").lower(),r.text[:500]
        except Exception as e: log_error("sheets",e); time.sleep(1)
    return False,"SHEETS_ERROR"
def send_to_crm(cat,data): ok,txt=send_crm("upsert",cat,data); return ok,txt,data.get("EWU_ID","")
def update_status(eid,status,coord=""): return send_crm("update_status","Pipeline",{"EWU_ID":eid,"Current_stage":status,"Responsible_manager":coord})
