import json
try: import google.generativeai as genai
except Exception: genai=None
try: from config import GEMINI_API_KEY
except Exception: GEMINI_API_KEY=""
if genai and GEMINI_API_KEY:
    try: genai.configure(api_key=GEMINI_API_KEY)
    except Exception: pass
MODEL=None
SYSTEM="You are EWU AI Coordinator of European Welders Union. Warm, professional, one question at a time, no guarantees."
def fallback(lang): return {"pl":"Rozumiem. Zapisuję i przejdziemy krok po kroku.","ua":"Зрозумів. Записую і підемо крок за кроком.","ru":"Понял. Записываю и пойдём шаг за шагом."}.get(lang,"Understood. Saved. We will proceed step by step.")
def get_model():
    global MODEL
    if MODEL: return MODEL
    if not genai or not GEMINI_API_KEY: return None
    for name in ["gemini-2.5-flash","gemini-2.5-flash-lite","gemini-2.5-pro"]:
        try:
            r=genai.GenerativeModel(name).generate_content("OK")
            MODEL=name; print("Gemini model selected:",name); return name
        except Exception as e: print("Gemini failed:",name,e)
    return None
def ai_reply(lang,role,state,user_text):
    name=get_model()
    if not name: return fallback(lang)
    try:
        prompt=f"{SYSTEM}\\nLanguage:{lang}\\nRole:{role}\\nData:{json.dumps(state.get('data',{}),ensure_ascii=False)}\\nUser:{user_text}\\nAnswer max 650 chars. Do not ask for phone."
        return (genai.GenerativeModel(name).generate_content(prompt).text or fallback(lang)).strip()[:1200]
    except Exception as e: print("Gemini ai_reply error:",e); return fallback(lang)
def ai_summary(lang,role,data,messages):
    name=get_model()
    if not name: return "AI summary unavailable. Manual verification required."
    try:
        prompt=f"Create Polish internal EWU summary. Role:{role}\\nData:{json.dumps(data,ensure_ascii=False)}\\nMessages:{json.dumps(messages[-8:],ensure_ascii=False)}"
        return (genai.GenerativeModel(name).generate_content(prompt).text or "AI summary unavailable.")[:2000]
    except Exception as e: print("Gemini ai_summary error:",e); return "AI summary unavailable. Manual verification required."
def ask_ai(lang,cat,state,text): return ai_reply(lang,cat,state,text)
def make_ai_summary(lang,cat,data,messages): return ai_summary(lang,cat,data,messages)
