import re
def extract(text,role):
    s=(text or "").lower(); d={}
    m=re.search(r"[\w\.-]+@[\w\.-]+\.\w+",text or "")
    if m: d["Email"]=m.group(0)
    m=re.search(r"\b(\d{2}[./-]\d{2}[./-]\d{4})\b",text or "")
    if m: d["Date_of_birth"]=m.group(1)
    for key,val in {"tig":"TIG Welder","mig":"MIG/MAG Welder","mag":"MIG/MAG Welder","mma":"MMA Welder","pipe":"Pipe Welder","spaw":"Welder","свар":"Welder","звар":"Welder","monter":"Fitter","fit":"Fitter"}.items():
        if key in s: d["Profession"]=d["Vacancy"]=d["Desired_position"]=val; break
    m=re.search(r"\b(\d{1,3})\s*(osób|people|workers|человек|людей)\b",s)
    if m and role=="employer": d["Quantity"]=m.group(1)
    m=re.search(r"\b(\d{1,2})\s*(lat|рок|years)\b",s)
    if m: d["Experience"]=m.group(0)
    m=re.search(r"\b(\d{2,4})\s*(zł|zl|pln|eur|€)\b",s)
    if m: d["Salary"]=m.group(0)
    if "gdańsk" in s or "gdansk" in s: d["City"]=d["Current_city"]="Gdańsk"
    if "berlin" in s: d["City"]=d["Current_city"]="Berlin"
    if "prawo jazdy" in s or "права" in s or "driver" in s: d["Driving_Licence"]="Yes"
    cats=re.findall(r"\b(B|C|CE|D|DE)\b",text or "",flags=re.I)
    if cats: d["Driving_Categories"]=", ".join([c.upper() for c in cats])
    return d
