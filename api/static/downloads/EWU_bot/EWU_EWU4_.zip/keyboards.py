from telebot import types
from i18n import t
def role_keyboard(lang="pl"):
    keys=["candidate","employer","legalization","relocation","family","business","help","language"]
    kb=types.InlineKeyboardMarkup(row_width=2)
    for i in range(0,8,2):
        kb.row(types.InlineKeyboardButton(t(lang,keys[i]),callback_data=f"role:{keys[i]}"),types.InlineKeyboardButton(t(lang,keys[i+1]),callback_data=f"role:{keys[i+1]}"))
    kb.row(types.InlineKeyboardButton("🎓 Education",callback_data="role:education"),types.InlineKeyboardButton("🛡 Protection",callback_data="role:protection"))
    kb.row(types.InlineKeyboardButton("🤝 Membership",callback_data="role:membership"),types.InlineKeyboardButton("🔁 Referral",callback_data="role:referral"))
    return kb
def lang_keyboard():
    kb=types.InlineKeyboardMarkup(row_width=2)
    kb.row(types.InlineKeyboardButton("Polski",callback_data="lang:pl"),types.InlineKeyboardButton("Українська",callback_data="lang:ua"))
    kb.row(types.InlineKeyboardButton("Русский",callback_data="lang:ru"),types.InlineKeyboardButton("English",callback_data="lang:en"))
    kb.row(types.InlineKeyboardButton("Deutsch",callback_data="lang:de"),types.InlineKeyboardButton("Español",callback_data="lang:es"))
    kb.row(types.InlineKeyboardButton("Português",callback_data="lang:pt"))
    return kb
def contact_keyboard(lang="pl"):
    kb=types.ReplyKeyboardMarkup(resize_keyboard=True,one_time_keyboard=True)
    kb.add(types.KeyboardButton("📞 "+{"pl":"Zostaw telefon","ua":"Залишити телефон","ru":"Оставить телефон","en":"Share phone","de":"Telefon teilen","es":"Enviar teléfono","pt":"Enviar telefone"}.get(lang,"Share phone"),request_contact=True))
    return kb
def yes_no_keyboard(lang="pl",prefix="yn"):
    kb=types.InlineKeyboardMarkup(row_width=2); kb.row(types.InlineKeyboardButton("✅ Yes",callback_data=f"{prefix}:yes"),types.InlineKeyboardButton("⏭ No",callback_data=f"{prefix}:no")); return kb
def status_keyboard(eid):
    kb=types.InlineKeyboardMarkup(row_width=2)
    for s in ["Application Completed","Documents Verified","Vacancy Matching","Interview","Contract Signed","Departure","Working","Archived"]:
        kb.add(types.InlineKeyboardButton(s,callback_data=f"status:{eid}:{s}"))
    return kb
def admin_keyboard():
    kb=types.InlineKeyboardMarkup(row_width=2); kb.row(types.InlineKeyboardButton("Pipeline",callback_data="admin:pipeline"),types.InlineKeyboardButton("Export",callback_data="admin:export")); return kb
