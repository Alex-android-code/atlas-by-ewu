import os,re,time,telebot
from telebot import types
from config import *
from i18n import t
from keyboards import role_keyboard,lang_keyboard,contact_keyboard,yes_no_keyboard,admin_keyboard
from language_detect import detect_lang
from ewu_id import new_candidate_id,new_employer_id
from extractor import extract
from ai import ai_reply,ai_summary
from crm import send_crm,ensure_dirs,update_status,log_error
from pdf_card import make_candidate_pdf,make_vacancy_pdf
from notifier import operations,leads

if not TELEGRAM_TOKEN: raise RuntimeError("TELEGRAM_TOKEN missing")
bot=telebot.TeleBot(TELEGRAM_TOKEN,parse_mode="HTML"); USERS={}; PHONE_RE=re.compile(r"(\+?\d[\d\s\-()]{7,18}\d)")
CAND=[("Full_Name","candidate_intro"),("Date_of_birth",{"pl":"Podaj datę urodzenia.","ua":"Напишіть дату народження.","ru":"Напишите дату рождения.","en":"Date of birth?"}),("Nationality",{"pl":"Jakie masz obywatelstwo?","ua":"Яке громадянство?","ru":"Какое гражданство?","en":"Nationality?"}),("Current_country",{"pl":"W jakim kraju jesteś teraz?","ua":"У якій країні ви зараз?","ru":"В какой стране вы сейчас?","en":"Current country?"}),("Current_city",{"pl":"W jakim mieście jesteś?","ua":"У якому місті?","ru":"В каком городе?","en":"Current city?"}),("Profession",{"pl":"Jaka profesja/specjalizacja?","ua":"Яка професія/спеціалізація?","ru":"Какая профессия/специализация?","en":"Profession/specialization?"}),("Experience",{"pl":"Ile lat doświadczenia?","ua":"Скільки років досвіду?","ru":"Сколько лет опыта?","en":"Years of experience?"}),("Welding_methods",{"pl":"Jakie metody spawania?","ua":"Які методи зварювання?","ru":"Какие методы сварки?","en":"Welding methods?"}),("Certificates",{"pl":"Czy masz certyfikaty?","ua":"Чи маєте сертифікати?","ru":"Есть сертификаты?","en":"Certificates?"}),("Certificate_validity",{"pl":"Do kiedy ważne?","ua":"До коли дійсні?","ru":"До когда действуют?","en":"Certificate validity?"}),("Foreign_experience",{"pl":"Doświadczenie za granicą?","ua":"Досвід за кордоном?","ru":"Опыт за границей?","en":"Foreign experience?"}),("Countries_worked_in",{"pl":"W jakich krajach pracowałeś?","ua":"У яких країнах працювали?","ru":"В каких странах работали?","en":"Countries worked in?"}),("Language_skills",{"pl":"Jakie języki i poziom?","ua":"Які мови і рівень?","ru":"Какие языки и уровень?","en":"Languages and level?"}),("Documents",{"pl":"Jakie dokumenty posiadasz?","ua":"Які документи маєте?","ru":"Какие документы есть?","en":"Documents?"}),("Relocation_readiness",{"pl":"Od kiedy gotowość do wyjazdu?","ua":"З якої дати готові?","ru":"С какой даты готовы?","en":"Relocation readiness?"}),("Preferred_countries",{"pl":"W jakich krajach chcesz pracować?","ua":"У яких країнах хочете працювати?","ru":"В каких странах хотите работать?","en":"Preferred countries?"}),("Overtime",{"pl":"Gotowość na nadgodziny?","ua":"Готові до понаднормових?","ru":"Готовы к сверхурочным?","en":"Overtime ready?"}),("Travel_ready",{"pl":"Gotowość do delegacji?","ua":"Готові до відряджень?","ru":"Готовы к командировкам?","en":"Travel ready?"}),("Team_lead_experience",{"pl":"Doświadczenie brygadzisty?","ua":"Досвід бригадира?","ru":"Опыт бригадира?","en":"Team lead experience?"}),("Driving_Licence",{"pl":"Czy masz prawo jazdy?","ua":"Чи маєте водійські права?","ru":"Есть водительские права?","en":"Driving licence?"}),("Driving_Categories",{"pl":"Jakie kategorie?","ua":"Які категорії?","ru":"Какие категории?","en":"Driving categories?"}),("Own_Vehicle",{"pl":"Czy masz własne auto?","ua":"Чи маєте власне авто?","ru":"Есть своё авто?","en":"Own vehicle?"}),("Phone","phone")]
EMP=[("Company","employer_intro"),("Contact_person",{"pl":"Osoba kontaktowa?","ua":"Контактна особа?","ru":"Контактное лицо?","en":"Contact person?"}),("Country",{"pl":"Kraj pracy?","ua":"Країна роботи?","ru":"Страна работы?","en":"Country?"}),("City",{"pl":"Miasto pracy?","ua":"Місто роботи?","ru":"Город работы?","en":"City?"}),("Vacancy",{"pl":"Jakich specjalistów potrzeba?","ua":"Яких спеціалістів потрібно?","ru":"Какие специалисты нужны?","en":"Specialists needed?"}),("Quantity",{"pl":"Ilu pracowników?","ua":"Скільки працівників?","ru":"Сколько работников?","en":"How many workers?"}),("Project_description",{"pl":"Opis projektu/produkcji?","ua":"Опис проєкту/виробництва?","ru":"Описание проекта/производства?","en":"Project description?"}),("Contract_type",{"pl":"Typ umowy?","ua":"Тип договору?","ru":"Тип договора?","en":"Contract type?"}),("Salary",{"pl":"Stawka/wynagrodzenie?","ua":"Ставка/зарплата?","ru":"Ставка/зарплата?","en":"Salary?"}),("Working_hours",{"pl":"Godziny miesięcznie?","ua":"Годин на місяць?","ru":"Часов в месяц?","en":"Monthly hours?"}),("Shifts",{"pl":"Zmiany/grafik?","ua":"Зміни/графік?","ru":"Смены/график?","en":"Shifts/schedule?"}),("Accommodation",{"pl":"Zakwaterowanie?","ua":"Житло?","ru":"Жильё?","en":"Accommodation?"}),("Transport",{"pl":"Transport?","ua":"Транспорт?","ru":"Транспорт?","en":"Transport?"}),("Work_clothing",{"pl":"Odzież robocza?","ua":"Робочий одяг?","ru":"Рабочая одежда?","en":"Work clothing?"}),("Meals",{"pl":"Wyżywienie/dopłaty?","ua":"Харчування/доплати?","ru":"Питание/доплаты?","en":"Meals/allowance?"}),("Starting_date",{"pl":"Data startu?","ua":"Дата старту?","ru":"Дата старта?","en":"Starting date?"}),("Phone","phone")]
def st(uid):
    if uid not in USERS: USERS[uid]={"lang":DEFAULT_LANG if DEFAULT_LANG in SUPPORTED_LANGS else "pl","role":"","data":{},"messages":[],"photo_path":"","production_photos":[],"accommodation_photos":[],"photo_mode":""}
    return USERS[uid]
def q(lang,x): return t(lang,x) if isinstance(x,str) else x.get(lang) or x.get("en") or "..."
def norm_phone(raw):
    p=re.sub(r"[^\d+]","",raw or "")
    if p.startswith("00"): p="+"+p[2:]
    if p.startswith("48") and not p.startswith("+"): p="+"+p
    if p.startswith("7") and len(p)==9: p="+48"+p
    return p
def find_phone(text):
    m=PHONE_RE.search(text or ""); return norm_phone(m.group(1)) if m else ""
def safe_send(chat_id,text,**kw):
    for _ in range(3):
        try: return bot.send_message(chat_id,text,**kw)
        except Exception as e: print("send error",e); log_error("telegram",e); time.sleep(1)
def safe_cb(c):
    try: bot.answer_callback_query(c.id)
    except Exception as e: print("callback error",e)
def send_start(chat,lang):
    if BANNER_FILE and os.path.exists(BANNER_FILE):
        try:
            with open(BANNER_FILE,"rb") as f: bot.send_photo(chat,f,caption=t(lang,"start"),reply_markup=role_keyboard(lang)); return
        except Exception as e: log_error("banner",e)
    safe_send(chat,t(lang,"start"),reply_markup=role_keyboard(lang))
def ask_next(m,u):
    fields=CAND if u["role"]=="candidate" else EMP if u["role"]=="employer" else []
    for field,question in fields:
        if not u["data"].get(field):
            if field=="Phone": safe_send(m.chat.id,q(u["lang"],question),reply_markup=contact_keyboard(u["lang"]))
            else: safe_send(m.chat.id,q(u["lang"],question))
            return
    finalize(m,u)
def finalize(m,u):
    data=u["data"]; role=u["role"]; lang=u["lang"]
    if not data.get("EWU_ID"): data["EWU_ID"]=new_employer_id() if role=="employer" else new_candidate_id()
    data.update({"Language":lang,"Telegram_ID":m.from_user.id,"Telegram":m.from_user.username or data.get("Telegram",""),"Type":role,"Current_Status":"Application Completed","AI_Summary":ai_summary(lang,role,data,u["messages"])})
    name=data.get("Full_Name") or data.get("Name") or data.get("Company","")
    send_crm("upsert","EWU Leads",{"Date":"","EWU_ID":data["EWU_ID"],"Type":role,"Name":name,"Language":lang,"Phone":data.get("Phone",""),"Source":"Telegram","Status":"New Lead","Comment":data["AI_Summary"]})
    send_crm("upsert","EWU Operations",data); send_crm("pipeline","Pipeline",{"EWU_ID":data["EWU_ID"],"Current_stage":"Application Completed","Transition_date":"","Responsible_manager":"","Next_step":"Coordinator follow-up","Deadline":""})
    pdf=make_vacancy_pdf(data,u["production_photos"],u["accommodation_photos"]) if role=="employer" else make_candidate_pdf(data,u.get("photo_path"))
    operations(bot,f"🆕 EWU lead\\nID: {data['EWU_ID']}\\nType: {role}\\nName: {name}\\nPhone: {data.get('Phone','')}\\n\\n{data['AI_Summary']}",pdf,data["EWU_ID"]); leads(bot,f"EWU: new {role} lead {data['EWU_ID']}")
    safe_send(m.chat.id,t(lang,"saved").format(id=data["EWU_ID"]),reply_markup=types.ReplyKeyboardRemove())
    if role=="candidate": safe_send(m.chat.id,t(lang,"photo_explain"))
    if role=="employer": safe_send(m.chat.id,"Would you like to add production photos?",reply_markup=yes_no_keyboard(lang,"prodphoto"))
@bot.message_handler(commands=["start"])
def start(m): u=st(m.from_user.id); u.update({"lang":"pl","role":"","data":{},"messages":[]}); send_start(m.chat.id,u["lang"])
@bot.message_handler(commands=["admin"])
def admin(m):
    if ADMIN_CHAT_ID and str(m.from_user.id)!=str(ADMIN_CHAT_ID): return
    safe_send(m.chat.id,"EWU Admin",reply_markup=admin_keyboard())
@bot.callback_query_handler(func=lambda c:c.data.startswith("lang:"))
def cb_lang(c): safe_cb(c); u=st(c.from_user.id); u["lang"]=c.data.split(":")[1]; send_start(c.message.chat.id,u["lang"])
@bot.callback_query_handler(func=lambda c:c.data.startswith("status:"))
def cb_status(c): safe_cb(c); _,eid,status=c.data.split(":",2); ok,info=update_status(eid,status,str(c.from_user.id)); safe_send(c.message.chat.id,"Status updated" if ok else str(info))
@bot.callback_query_handler(func=lambda c:c.data.startswith("prodphoto:") or c.data.startswith("accomphoto:"))
def cb_ph(c):
    safe_cb(c); u=st(c.from_user.id); pref,val=c.data.split(":")
    if pref=="prodphoto":
        if val=="yes": u["photo_mode"]="production"; safe_send(c.message.chat.id,"Send production photos. Write OK when finished.")
        else: safe_send(c.message.chat.id,"Would you like to add accommodation photos?",reply_markup=yes_no_keyboard(u["lang"],"accomphoto"))
    else:
        if val=="yes": u["photo_mode"]="accommodation"; safe_send(c.message.chat.id,"Send accommodation photos. Write OK when finished.")
        else: finalize(c.message,u)
@bot.callback_query_handler(func=lambda c:c.data.startswith("role:"))
def cb_role(c):
    safe_cb(c); role=c.data.split(":")[1]; u=st(c.from_user.id)
    if role=="language": safe_send(c.message.chat.id,t(u["lang"],"choose_lang"),reply_markup=lang_keyboard()); return
    u.update({"role":role,"messages":[],"photo_mode":"","production_photos":[],"accommodation_photos":[]})
    u["data"]={"EWU_ID":new_employer_id() if role=="employer" else new_candidate_id(),"Language":u["lang"],"Telegram_ID":c.from_user.id,"Telegram":c.from_user.username or "","Source":"Telegram","Type":role}
    if role in ["candidate","employer"]: ask_next(c.message,u)
    else: safe_send(c.message.chat.id,{"education":"Education request","protection":"Worker protection request","membership":"Membership request","referral":"Referral request"}.get(role,f"Describe your {role} request."))
@bot.message_handler(content_types=["contact"])
def contact(m): u=st(m.from_user.id); u["data"]["Phone"]=norm_phone(m.contact.phone_number if m.contact else ""); finalize(m,u)
@bot.message_handler(content_types=["photo"])
def photo(m):
    u=st(m.from_user.id); os.makedirs(os.path.join(EWU_DATA_DIR,"Photos"),exist_ok=True)
    try:
        info=bot.get_file(m.photo[-1].file_id); content=bot.download_file(info.file_path); path=os.path.join(EWU_DATA_DIR,"Photos",f"{u['data'].get('EWU_ID','photo')}_{m.photo[-1].file_id}.jpg")
        open(path,"wb").write(content)
        if u.get("photo_mode")=="production": u["production_photos"].append(path); u["data"]["Production_Photos"]=";".join(u["production_photos"])
        elif u.get("photo_mode")=="accommodation": u["accommodation_photos"].append(path); u["data"]["Accommodation_Photos"]=";".join(u["accommodation_photos"])
        else: u["photo_path"]=path; u["data"]["Photo"]=path
        safe_send(m.chat.id,t(u["lang"],"photo_ok"))
    except Exception as e: log_error("photo",e)
@bot.message_handler(func=lambda m:True)
def dialog(m):
    u=st(m.from_user.id); text=m.text or ""
    if not u.get("role"): u["lang"]=detect_lang(text); safe_send(m.chat.id,t(u["lang"],"start"),reply_markup=role_keyboard(u["lang"])); return
    if text.lower().strip() in ["ok","done","готово"]:
        if u.get("photo_mode")=="production": u["photo_mode"]=""; safe_send(m.chat.id,"Would you like to add accommodation photos?",reply_markup=yes_no_keyboard(u["lang"],"accomphoto")); return
        if u.get("photo_mode")=="accommodation": u["photo_mode"]=""; finalize(m,u); return
    p=find_phone(text)
    if p: u["data"]["Phone"]=p; finalize(m,u); return
    u["messages"].append({"user":text})
    for k,v in extract(text,u["role"]).items():
        if v and not u["data"].get(k): u["data"][k]=v
    fields=CAND if u["role"]=="candidate" else EMP if u["role"]=="employer" else []
    for field,_ in fields:
        if not u["data"].get(field): u["data"][field]=text.strip(); break
    safe_send(m.chat.id,ai_reply(u["lang"],u["role"],u,text))
    if u["role"] in ["candidate","employer"]: ask_next(m,u)
    elif not u["data"].get("Phone"): safe_send(m.chat.id,t(u["lang"],"phone"),reply_markup=contact_keyboard(u["lang"]))
if __name__=="__main__":
    ensure_dirs(); print("EWU European Welders Union 4.0 started")
    while True:
        try: bot.infinity_polling(skip_pending=True,timeout=20,long_polling_timeout=20,restart_on_change=False)
        except Exception as e: print("polling error",e); log_error("polling",e); time.sleep(5)
