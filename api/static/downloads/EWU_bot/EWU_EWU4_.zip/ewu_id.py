from datetime import datetime
import random
def new_candidate_id(): return f"EWU-PL-{datetime.now().year}-{random.randint(1,99999):05d}"
def new_employer_id(): return f"EWU-EMP-{datetime.now().year}-{random.randint(1,99999):05d}"
