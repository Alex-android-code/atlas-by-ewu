def detect_lang(text):
    s=(text or "").lower()
    if any(x in s for x in ["ї","є","робота","звар"]): return "ua"
    if any(x in s for x in ["работа","свар","документ"]): return "ru"
    if any(x in s for x in ["arbeit","schwei"]): return "de"
    if any(x in s for x in ["trabajo","soldador"]): return "es"
    if any(x in s for x in ["trabalho","soldador"]): return "pt"
    if any(x in s for x in ["work","welder","employer"]): return "en"
    return "pl"
