import os
from config import OPERATIONS_CHAT_ID,LEADS_CHANNEL_ID
from keyboards import status_keyboard
def operations(bot,text,document=None,ewu_id=None):
    if not OPERATIONS_CHAT_ID: return False
    try:
        bot.send_message(OPERATIONS_CHAT_ID,text,reply_markup=status_keyboard(ewu_id) if ewu_id else None)
        if document and os.path.exists(document):
            with open(document,"rb") as f: bot.send_document(OPERATIONS_CHAT_ID,f)
        return True
    except Exception as e: print("operations error:",e); return False
def leads(bot,text):
    if not LEADS_CHANNEL_ID: return False
    try: bot.send_message(LEADS_CHANNEL_ID,text); return True
    except Exception as e: print("leads error:",e); return False
