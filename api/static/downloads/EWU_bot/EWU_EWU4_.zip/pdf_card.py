import os,qrcode
from reportlab.lib.pagesizes import A4
from reportlab.lib import colors
from reportlab.platypus import SimpleDocTemplate,Paragraph,Spacer,Table,TableStyle,Image as RLImage
from reportlab.lib.styles import getSampleStyleSheet,ParagraphStyle
from reportlab.lib.units import cm
from config import PDF_DIR,LOGO_FILE
def tab(rows):
    t=Table(rows,colWidths=[5*cm,11*cm]); t.setStyle(TableStyle([("BACKGROUND",(0,0),(0,-1),colors.HexColor("#EAF2F8")),("GRID",(0,0),(-1,-1),0.4,colors.HexColor("#D8E6F2")),("FONTNAME",(0,0),(0,-1),"Helvetica-Bold"),("PADDING",(0,0),(-1,-1),6)])); return t
def make_candidate_pdf(data,photo_path=None):
    os.makedirs(PDF_DIR,exist_ok=True); eid=data.get("EWU_ID","EWU"); path=os.path.join(PDF_DIR,f"{eid}_candidate.pdf")
    doc=SimpleDocTemplate(path,pagesize=A4); st=getSampleStyleSheet(); title=ParagraphStyle("T",parent=st["Title"],textColor=colors.HexColor("#102E46"),fontSize=21)
    story=[]
    if os.path.exists(LOGO_FILE): story.append(RLImage(LOGO_FILE,width=2.2*cm,height=2.2*cm))
    story += [Paragraph("European Welders Union — Candidate Card",title),Paragraph(f"<b>EWU ID:</b> {eid}",st["BodyText"]),Spacer(1,8)]
    if photo_path and os.path.exists(photo_path): story += [RLImage(photo_path,width=4*cm,height=4*cm),Spacer(1,8)]
    q=os.path.join(PDF_DIR,f"{eid}_qr.png"); qrcode.make(eid).save(q); story.append(RLImage(q,width=2*cm,height=2*cm))
    rows=[["Full name",data.get("Full_Name") or data.get("Name","")],["Birth",data.get("Date_of_birth","")],["Nationality",data.get("Nationality","")],["Profession",data.get("Profession","")],["Experience",data.get("Experience","")],["Welding methods",data.get("Welding_methods","")],["Certificates",data.get("Certificates","")],["Languages",data.get("Language_skills","")],["Documents",data.get("Documents","")],["Driving licence",data.get("Driving_Licence","")],["Categories",data.get("Driving_Categories","")],["Own vehicle",data.get("Own_Vehicle","")],["Contacts",data.get("Phone","")],["AI Summary",data.get("AI_Summary","")]]
    story.append(tab(rows)); doc.build(story); return path
def make_vacancy_pdf(data,prod=None,acc=None):
    os.makedirs(PDF_DIR,exist_ok=True); eid=data.get("EWU_ID","EWU_EMP"); path=os.path.join(PDF_DIR,f"{eid}_vacancy.pdf")
    doc=SimpleDocTemplate(path,pagesize=A4); st=getSampleStyleSheet(); title=ParagraphStyle("T",parent=st["Title"],textColor=colors.HexColor("#102E46"),fontSize=21)
    rows=[["Company",data.get("Company","")],["Country/City",data.get("Country","")+" "+data.get("City","")],["Profession",data.get("Vacancy","")],["Quantity",data.get("Quantity","")],["Salary",data.get("Salary","")],["Contract",data.get("Contract_type","")],["Accommodation",data.get("Accommodation","")],["Transport",data.get("Transport","")],["Contact",data.get("Phone","")]]
    doc.build([Paragraph("European Welders Union — Vacancy Card",title),tab(rows)]); return path
def make_pdf(data,photo_path=None): return make_candidate_pdf(data,photo_path)
